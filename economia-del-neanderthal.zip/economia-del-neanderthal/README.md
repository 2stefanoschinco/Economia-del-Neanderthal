# Economia del Neanderthal

Catalogo consultabile, aperto. Non è l’archivio: l’archivio resta su Zenodo e OSF (DOI persistenti). Questo repository è l’indice — dove si consultano insieme figure, tesi e fonti.

> Autorità è la custodia del logos.  
> Potere è la cattura del polemos.

## Figure

Le tre tavole vanno caricate nella cartella [`figure/`](figure/) (GitHub web: *Add file → Upload*). Poi i link sotto funzionano.

1. **Nati / Acqua / PIL / Campi** — soglie demografiche e materiali  
   `figure/01-nati-acqua-campi.png`

2. **Sotto / dentro / sopra** — quote di reddito, nati, debito e prezzi  
   `figure/02-sotto-dentro-sopra.png`

3. **Stella o buco nero** — shuttle, Paracelso, leva eraclitea  
   `figure/03-stella-o-buco-nero.jpg`

Testo in calce alle tavole 1–2 (come nelle figure):

- Nati: UN / Istat. Punto 0 dichiarato = 2 (non 2,1). Sotto quella riga la generazione non si sostituisce.
- Acqua: FAO AQUASTAT 2022. 100% = ciclo rinnovabile dopo deflusso ambientale. Golfo e N-Africa già oltre.
- Campi: FAOSTAT cropland ha/ab. Mondo circa −20% dal 2000.
- Soglie 10% e 40% del PIL/ab USA dello stesso anno (nominale). Il «dentro» è quasi solo la Cina.

Questi numeri sono **verità deboli**: dipendono da deflatore, soglia scelta, classificazione UN WPP. La direzione (nascite sotto soglia, prelievo idrico oltre ciclo, cropland/ab in calo, debito che corre coi prezzi) è più robusta del decimale.

## Riflessione

Tra Neanderthal e cerchio del fuoco — senza vocabolario economico da manuale.

### 1. Phantasiai istituzionale — Pi

Pi è la direzione in cui norme primarie, norme secondarie e prassi (moduli, tempi, costi, accesso) spostano liquidità e **contendibilità** dei beni essenziali, dei collateral e dei sistemi di coordinamento.

Non è l’intenzione della legge. È ciò che la legge *fa* alla contendibilità.

- Se «aiutiamo le imprese» richiede 40 moduli, un commercialista e 8 mesi, Pi è negativa: il bene diventa captive.
- Se la norma rende garanzia, competenza e collateral di nuovo rinegoziabili, Pi è positiva: circolazione.

Ogni norma ha funzione manifesta (ciò che dichiara) e latente (ciò che fa). Pi è somma algebrica. Non ha morale. È la percezione che la popolazione ha delle istituzioni, sedimentata.

### 2. Potere contrattuale — Pcc e PcBSI

Potere contrattuale è la capacità di far valere una scrittura — o una posizione — come obbligazione altrui. Non è invenzione moderna. Non è, di per sé, un male. Diventa controproduttivo quando smette di circolare e si consolida **ex ante**.

| Polo | Nome | Tempo | Funzione |
|------|------|-------|----------|
| Pcc | Potere che chiude la contesa | ex ante | Decide le regole del giro successivo prima che il giro inizi |
| PcBSI | Potere della base sociale industriosa | ex post, ogni giorno | Mettere in banca, negoziare, rientrare, rinegoziare |

Senza Pcc non investi (brevetto, garanzia). Senza PcBSI non generi ricchezza. Anche chi sta in PcBSI, se può, vuole chiudere. La tensione è il sistema, non un incidente.

ΔPcc è funzione inversa di Pi × PcBSI. Se Pi spinge all’accumulo, PcBSI si erode e Pcc si cumula anche senza cattiveria.

### 3. VEC — Verità effettuale della concrescenza

Machiavelli: non come dovrebbe essere, ma come cade a terra.  
Whitehead: concrescenza — da molte prehensions a una realtà.

Se consumi capacità senza rigenerarla e predichi sostenibilità senza cambiare *come misuri* (a) e *come tieni insieme* (x = Pi), non stai creando: stai scavando. Quando E diventa negativo, non insistere. Inverti. L’errore è informazione (isteresi, disequilibrio che tiene storia).

Come stanno insieme i tre: Pi è la contesa istituzionale; Pcc/PcBSI decide se l’ipotesi resta aperta; VEC dice se c’è energia per passare da ipotesi a entelechia o se il sistema resta in buca.

### Arché e Kratos (tetralogia)

Seguendo Cicerone (*De Leg.* 3.28) e Bachofen:  
**Kratos** = capacità di chiudere un conflitto determinando una forma.  
**Arché** = capacità di custodire e far crescere il significato di quella forma nel tempo.  
Sono inversamente proporzionali.

Aristotele: *arché* ordina per il bene comune; *kratos* è dominio di una parte.  
Castoriadis: il kratos che finge di essere auctoritas è l’alienazione politica.

Elenco comparato (22 + 22): [`testi/arche-kratos.md`](testi/arche-kratos.md)

## Fonti DOI (depositi, non copie)

Aggiungere un progetto = aggiungere una riga. Il file canonico vive su Zenodo o OSF. Qui vive il puntatore.

| Titolo breve | Sede | DOI |
|--------------|------|-----|
| IPI — famiglia di strumenti | Zenodo | [10.5281/zenodo.22645188](https://doi.org/10.5281/zenodo.22645188) |
| IPI — statistiche e scheda applicativa | OSF | [10.17605/OSF.IO/8YVB6](https://doi.org/10.17605/OSF.IO/8YVB6) |
| Cerchio di fuoco — immagini e intro | OSF | [10.17605/OSF.IO/DA8BP](https://doi.org/10.17605/OSF.IO/DA8BP) |
| RR e DL, Paracelso, stella o buco nero | OSF | [10.17605/OSF.IO/XCEDS](https://doi.org/10.17605/OSF.IO/XCEDS) |
| Tetralogia del depende | Zenodo | [10.5281/zenodo.22694824](https://doi.org/10.5281/zenodo.22694824) |
| Il viaggio | OSF | [10.17605/OSF.IO/9M5EG](https://doi.org/10.17605/OSF.IO/9M5EG) |
| Abbaglio nella nebbia | OSF | [10.17605/OSF.IO/4UFDN](https://doi.org/10.17605/OSF.IO/4UFDN) |
| I tre piani inclinati | OSF | [10.17605/OSF.IO/FZ4T8](https://doi.org/10.17605/OSF.IO/FZ4T8) |
| Nati da Lucy e sfamati dall'acqua | OSF | [10.17605/OSF.IO/SXKQ2](https://doi.org/10.17605/OSF.IO/SXKQ2) |

Comunità Zenodo: [Cerchio del Fuoco](https://zenodo.org/communities/cechio_del_fuoco/records)

## Come aggiungere un progetto da Zenodo o OSF

Non si «importa» il record. Si **punta**.

1. Apri il record su Zenodo o OSF. Copia il DOI (forma `10.…`, non solo l’URL della pagina).
2. Modifica questo README (matita in alto a destra su GitHub) oppure il file `fonti/doi.md`.
3. Aggiungi una riga alla tabella: titolo breve, sede (Zenodo/OSF), link `https://doi.org/10.…`.
4. Commit. Il catalogo è aggiornato. Chi consulta clicca il DOI e atterra sulla versione persistente.

Opzionale, più avanti:

- **Zenodo ↔ GitHub**: se un giorno versioni *codice* in questo repo, Zenodo può mintare un DOI a ogni *Release*. Utile per software, non per un indice di paper già depositati altrove.
- **OSF ↔ GitHub**: da un progetto OSF si può «Add-on → GitHub» e specchiare una cartella. Serve se vuoi che OSF mostri questo catalogo, non il contrario.
- Non duplicare PDF pesanti qui. GitHub non è archivio; il file canonico resta dove ha il DOI.

## Cartelle

```
economia-del-neanderthal/
  README.md              ← sei qui
  figure/                ← le tre tavole
  testi/                 ← arche-kratos e note
  fonti/                 ← tabella DOI speculare, per chi vuole solo le fonti
```
