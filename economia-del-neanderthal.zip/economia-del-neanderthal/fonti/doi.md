# Fonti DOI

Il file vivo è il [README](../README.md). Questa pagina è lo specchio minimo.

| Titolo breve | Sede | DOI |
|--------------|------|-----|
| IPI — famiglia di strumenti | Zenodo | [10.5281/zenodo.22645188](https://doi.org/10.5281/zenodo.22645188) |
| IPI — statistiche e scheda | OSF | [10.17605/OSF.IO/8YVB6](https://doi.org/10.17605/OSF.IO/8YVB6) |
| Cerchio di fuoco | OSF | [10.17605/OSF.IO/DA8BP](https://doi.org/10.17605/OSF.IO/DA8BP) |
| RR / DL / Paracelso | OSF | [10.17605/OSF.IO/XCEDS](https://doi.org/10.17605/OSF.IO/XCEDS) |
| Tetralogia del depende | Zenodo | [10.5281/zenodo.22694824](https://doi.org/10.5281/zenodo.22694824) |
| Il viaggio | OSF | [10.17605/OSF.IO/9M5EG](https://doi.org/10.17605/OSF.IO/9M5EG) |
| Abbaglio nella nebbia | OSF | [10.17605/OSF.IO/4UFDN](https://doi.org/10.17605/OSF.IO/4UFDN) |
| I tre piani inclinati | OSF | [10.17605/OSF.IO/FZ4T8](https://doi.org/10.17605/OSF.IO/FZ4T8) |
| Nati da Lucy e sfamati dall'acqua | OSF | [10.17605/OSF.IO/SXKQ2](https://doi.org/10.17605/OSF.IO/SXKQ2) |
