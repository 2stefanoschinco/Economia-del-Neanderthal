# Arché / Autoritas e Kratos / Potestas

Due liste. Non sono simmetriche per cortesia: sono due funzioni. La prima custisce il logos; la seconda cattura il polemos.

## Autorità — custodia del logos (funzioni manifeste)

1. Tianming (Cina — Mandato del Cielo)
2. Asabiyyah (Ibn Khaldun — solidarietà di gruppo)
3. Oikonomia (Grecia — amministrazione orientata al bene)
4. Aequalitas / Iustum pretium (Roma-Medioevo)
5. Vital force / force vitale (tradizioni africane)
6. Clan Mothers authority (Haudenosaunee / Irochesi)
7. Royaner (capo della Grande Legge della Pace)
8. Sapa Inka come mediatore cosmico (Inca)
9. Divine king / k’uhul ajaw (Maya)
10. Ariki / Rangatira (Maori)
11. Kīngitanga (movimento del re Māori)
12. Curaca legittimo (Ande)
13. Chieftainship without coercion (Clastres)
14. Elder / lineage elder (Africa tradizionale)
15. Potere contrattuale ex post (esito contestabile)
16. Derzhava divina / pomazannik (Russia ortodossa)
17. De (virtù / potenza morale — Cina confuciana)
18. Great Law of Peace (Haudenosaunee)
19. Huaca / ancestor mediation (Ande)
20. Respect / knowledge custodianship (Aboriginal Australian)
21. Wazi’ / restraining power giusto (Khaldun)
22. Logos come relazione tra le cose (Eraclito)

## Potere — cattura del polemos (funzioni latenti)

1. Chrematistics (Aristotele)
2. Ba / forza coercitiva (Cina — Legalismo)
3. Siloviki / sila (Russia)
4. Vlast’ coercitiva (Russia)
5. Tyranny / despotic rule
6. Capture of vital force (abuso)
7. Coercive chieftainship (opposto a Clastres)
8. Potere conteso / conflitto per l’autorità
9. Laesio enormis (diritto romano)
10. Controproduttività (Illich)
11. Potere contrattuale ex ante (chiude prima della contesa)
12. Complesso militare-industriale (Eisenhower)
13. Military supremacy senza mandato (Cina post-Zhou)
14. Despotismo decentralizzato (Africa coloniale e post-coloniale)
15. Power as coercion (Clastres, definizione negativa)
16. Usurpazione del Sapa Inka
17. Forced labour / mit’a coercitiva (quando degenera)
18. Patronage capture
19. Absolute potestas senza auctoritas (Roma degenerata)
20. Force structures senza legitimation (Russia)
21. Domination through violence or threat
22. Cattura del polemos (Eraclito)

## Nota di lavoro

Kratos chiude e determina una forma. Arché la fa crescere nel tempo.  
Pcc è kratos sedimentato nelle regole dello scambio. PcBSI è arché debole, quotidiana, revocabile ogni giorno.
