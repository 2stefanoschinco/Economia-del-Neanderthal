# Figure

Caricare qui i tre file (stessi nomi usati nel README principale):

- `01-nati-acqua-campi.png`
- `02-sotto-dentro-sopra.png`
- `03-stella-o-buco-nero.jpg`

Su GitHub: questa cartella → **Add file** → **Upload files**.
